package Controladora;

import Dominio.Hotel;
import Persistencia.PHotel;

import java.util.ArrayList;
import java.util.Scanner;

public class ControladoraHotel {
    private static Scanner escaner = new Scanner(System.in);

    public void agregarHotel() {
        System.out.println("Agregar hotel");

        int idHotel;
        do {
            System.out.print("Ingrese ID del hotel: ");
            try {
                idHotel = Integer.parseInt(escaner.nextLine());
            } catch (Exception e) {
                idHotel = 0;
                System.out.println("ID inválido. Intente nuevamente.");
            }
        } while (idHotel == 0);

        System.out.print("Ingrese el nombre del hotel: ");
        String nombre = escaner.nextLine();

        System.out.print("Ingrese la ciudad del hotel: ");
        String ciudad = escaner.nextLine();

        System.out.print("Ingrese el país del hotel: ");
        String pais = escaner.nextLine();

        System.out.print("Ingrese la cantidad de estrellas: ");
        int estrellas = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese la dirección del hotel: ");
        String direccion = escaner.nextLine();

        System.out.print("Ingrese la zona del hotel: ");
        String zona = escaner.nextLine();

        Hotel hotel = new Hotel(idHotel, nombre, ciudad, pais, estrellas, direccion, zona, new ArrayList<>());

        if (PHotel.agregarHotel(hotel)) {
            System.out.println("Hotel agregado con éxito.");
        } else {
            System.out.println("Hubo un error al agregar el hotel.");
        }
    }

    public void eliminarHotel() {
        System.out.print("Ingrese ID del hotel a eliminar: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        if (PHotel.eliminarHotel(idHotel)) {
            System.out.println("Hotel eliminado con éxito.");
        } else {
            System.out.println("No se pudo eliminar el hotel.");
        }
    }

    public void modificarHotel() {
        System.out.print("Ingrese ID del hotel a modificar: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        Hotel hotel = PHotel.listarHoteles().stream().filter(h -> h.getIdHotel() == idHotel).findFirst().orElse(null);
        if (hotel == null) {
            System.out.println("Hotel no encontrado.");
            return;
        }

        System.out.print("Ingrese el nombre del hotel (" + hotel.getNombre() + "): ");
        String nombre = escaner.nextLine();
        if (!nombre.isEmpty()) hotel.setNombre(nombre);

        System.out.print("Ingrese la ciudad del hotel (" + hotel.getCiudad() + "): ");
        String ciudad = escaner.nextLine();
        if (!ciudad.isEmpty()) hotel.setCiudad(ciudad);

        System.out.print("Ingrese el país del hotel (" + hotel.getPais() + "): ");
        String pais = escaner.nextLine();
        if (!pais.isEmpty()) hotel.setPais(pais);

        System.out.print("Ingrese la cantidad de estrellas (" + hotel.getEstrellas() + "): ");
        String estrellasStr = escaner.nextLine();
        if (!estrellasStr.isEmpty()) hotel.setEstrellas(Integer.parseInt(estrellasStr));

        System.out.print("Ingrese la dirección del hotel (" + hotel.getDireccion() + "): ");
        String direccion = escaner.nextLine();
        if (!direccion.isEmpty()) hotel.setDireccion(direccion);

        System.out.print("Ingrese la zona del hotel (" + hotel.getZona() + "): ");
        String zona = escaner.nextLine();
        if (!zona.isEmpty()) hotel.setZona(zona);

        if (PHotel.modificarHotel(hotel)) {
            System.out.println("Hotel modificado con éxito.");
        } else {
            System.out.println("Hubo un error al modificar el hotel.");
        }
    }

    public void conseguirHotel() {
        System.out.print("Ingrese ID del hotel: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        Hotel hotel = PHotel.conseguirHotel(idHotel);
        if (hotel != null) {
            System.out.println(hotel);
        } else {
            System.out.println("Hotel no encontrado.");
        }
    }

    public void listarHoteles() {
        System.out.println("Listado de hoteles:");
        for (Hotel hotel : PHotel.listarHoteles()) {
            System.out.println(hotel);
        }
    }
    public void consultarHotelesPorCiudad() {
        System.out.print("Ingrese la ciudad: ");
        String ciudad = escaner.nextLine();

        System.out.println("Hoteles en la ciudad " + ciudad + ":");
        PHotel.listarHoteles().stream()
                .filter(hotel -> hotel.getCiudad().equalsIgnoreCase(ciudad))
                .forEach(System.out::println);
    }

    public void consultarHotelesPorNombre() {
        System.out.print("Ingrese el nombre del hotel: ");
        String nombre = escaner.nextLine();

        System.out.println("Hoteles con el nombre " + nombre + ":");
        PHotel.listarHoteles().stream()
                .filter(hotel -> hotel.getNombre().equalsIgnoreCase(nombre))
                .forEach(System.out::println);
    }

    public void consultarHotelesPorEstrellas() {
        System.out.print("Ingrese la cantidad de estrellas: ");
        int estrellas = Integer.parseInt(escaner.nextLine());

        System.out.println("Hoteles con " + estrellas + " estrellas:");
        PHotel.listarHoteles().stream()
                .filter(hotel -> hotel.getEstrellas() == estrellas)
                .forEach(System.out::println);
    }

}
