package Controladora;

import Dominio.Huesped;
import Dominio.Hotel;
import Dominio.Habitacion;
import Dominio.Reserva;
import Persistencia.PHuesped;
import Persistencia.PHotel;
import Persistencia.PHabitacion;
import Persistencia.PReserva;

import java.time.LocalDate;
import java.util.Scanner;

public class ControladoraReserva {
    private static final Scanner escaner = new Scanner(System.in);

    public void agregarReserva() {
        System.out.println("Agregar reserva");

        System.out.print("Ingrese ID del huésped: ");
        int idHuesped = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese ID del hotel: ");
        int idHotel = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese ID de la habitación: ");
        int idHabitacion = Integer.parseInt(escaner.nextLine());

        Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
        Hotel hotel = PHotel.conseguirHotel(idHotel);
        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);

        if (huesped == null || hotel == null || habitacion == null) {
            System.out.println("No se pudo encontrar uno de los objetos requeridos para la reserva.");
            return;
        }

        System.out.print("Ingrese cantidad de personas: ");
        int cantidadPersonas = Integer.parseInt(escaner.nextLine());

        System.out.print("Ingrese fecha de inicio (YYYY-MM-DD): ");
        LocalDate fechaInicio = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese fecha de fin (YYYY-MM-DD): ");
        LocalDate fechaFin = LocalDate.parse(escaner.nextLine());

        if (fechaInicio.isAfter(fechaFin)) {
            System.out.println("Error: La fecha de inicio no puede ser posterior a la fecha de fin.");
            return;
        }

        System.out.print("¿La reserva está pagada? (true/false): ");
        boolean pagada = Boolean.parseBoolean(escaner.nextLine());

        System.out.print("Ingrese fecha de la reserva (YYYY-MM-DD): ");
        LocalDate fechaReserva = LocalDate.parse(escaner.nextLine());

        System.out.print("Ingrese alguna observación: ");
        String observacion = escaner.nextLine();

        Reserva reserva = new Reserva(0, huesped, hotel, habitacion, cantidadPersonas,
                fechaInicio, fechaFin, pagada, fechaReserva, observacion);

        if (PReserva.agregarReserva(reserva)) {
            System.out.println("Reserva agregada con éxito.");
        } else {
            System.out.println("Error al agregar la reserva.");
        }
    }

    public void eliminarReserva() {
        System.out.print("Ingrese ID de la reserva a eliminar: ");
        int idReserva = Integer.parseInt(escaner.nextLine());

        if (PReserva.eliminarReserva(idReserva)) {
            System.out.println("Reserva eliminada con éxito.");
        } else {
            System.out.println("Error al eliminar la reserva.");
        }
    }

    public void modificarReserva() {
        System.out.print("Ingrese ID de la reserva a modificar: ");
        int idReserva = Integer.parseInt(escaner.nextLine());

        Reserva reserva = PReserva.conseguirReserva(idReserva);
        if (reserva == null) {
            System.out.println("Reserva no encontrada.");
            return;
        }

        System.out.print("Ingrese fecha de inicio (YYYY-MM-DD) [" + reserva.getFechaInicio() + "]: ");
        String fechaInicioStr = escaner.nextLine();
        LocalDate fechaInicio = fechaInicioStr.isEmpty() ? reserva.getFechaInicio() : LocalDate.parse(fechaInicioStr);

        System.out.print("Ingrese fecha de fin (YYYY-MM-DD) [" + reserva.getFechaFin() + "]: ");
        String fechaFinStr = escaner.nextLine();
        LocalDate fechaFin = fechaFinStr.isEmpty() ? reserva.getFechaFin() : LocalDate.parse(fechaFinStr);

        if (fechaInicio.isAfter(fechaFin)) {
            System.out.println("Error: La fecha de inicio no puede ser posterior a la fecha de fin.");
            return;
        }

        reserva.setFechaInicio(fechaInicio);
        reserva.setFechaFin(fechaFin);

        System.out.print("Ingrese cantidad de personas (" + reserva.getCantidadPersonas() + "): ");
        String cantidadPersonasStr = escaner.nextLine();
        if (!cantidadPersonasStr.isEmpty()) {
            reserva.setCantidadPersonas(Integer.parseInt(cantidadPersonasStr));
        }

        System.out.print("¿Está pagada? (" + reserva.isPagada() + "): ");
        String pagadaStr = escaner.nextLine();
        if (!pagadaStr.isEmpty()) {
            reserva.setPagada(Boolean.parseBoolean(pagadaStr));
        }

        System.out.print("Ingrese alguna observación (" + reserva.getObservacion() + "): ");
        String observacion = escaner.nextLine();
        if (!observacion.isEmpty()) {
            reserva.setObservacion(observacion);
        }

        if (PReserva.modificarReserva(reserva)) {
            System.out.println("Reserva modificada con éxito.");
        } else {
            System.out.println("Error al modificar la reserva.");
        }
    }

    public void conseguirReserva() {
        System.out.print("Ingrese ID de la reserva a buscar: ");
        int idReserva = Integer.parseInt(escaner.nextLine());

        Reserva reserva = PReserva.conseguirReserva(idReserva);
        if (reserva != null) {
            System.out.println(reserva);
        } else {
            System.out.println("Reserva no encontrada.");
        }
    }

    public void listarReservas() {
        System.out.println("Listado de reservas:");
        for (Reserva reserva : PReserva.listarReservas()) {
            System.out.println(reserva);
        }
    }
}
