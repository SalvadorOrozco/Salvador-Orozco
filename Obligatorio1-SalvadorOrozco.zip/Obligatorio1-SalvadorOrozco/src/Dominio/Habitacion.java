package Dominio;

public class Habitacion {
    private int idHabitacion;
    private int capacidadCamas;
    private boolean camaMatrimonial;
    private boolean aireAcondicionado;
    private boolean balcon;
    private boolean vista;
    private boolean amenities;
    private boolean ocupada;
    private Hotel hotel; // Relación con la clase Hotel

    public Habitacion(int idHabitacion, int capacidadCamas, boolean camaMatrimonial,
                      boolean aireAcondicionado, boolean balcon, boolean vista,
                      boolean amenities, boolean ocupada, Hotel hotel) {
        this.idHabitacion = idHabitacion;
        this.capacidadCamas = capacidadCamas;
        this.camaMatrimonial = camaMatrimonial;
        this.aireAcondicionado = aireAcondicionado;
        this.balcon = balcon;
        this.vista = vista;
        this.amenities = amenities;
        this.ocupada = ocupada;
        this.hotel = hotel; // Inicialización del objeto Hotel
    }

    // Getters y Setters
    public int getIdHabitacion() {
        return idHabitacion;
    }

    public void setIdHabitacion(int idHabitacion) {
        this.idHabitacion = idHabitacion;
    }

    public int getCapacidadCamas() {
        return capacidadCamas;
    }

    public void setCapacidadCamas(int capacidadCamas) {
        this.capacidadCamas = capacidadCamas;
    }

    public boolean isCamaMatrimonial() {
        return camaMatrimonial;
    }

    public void setCamaMatrimonial(boolean camaMatrimonial) {
        this.camaMatrimonial = camaMatrimonial;
    }

    public boolean isAireAcondicionado() {
        return aireAcondicionado;
    }

    public void setAireAcondicionado(boolean aireAcondicionado) {
        this.aireAcondicionado = aireAcondicionado;
    }

    public boolean isBalcon() {
        return balcon;
    }

    public void setBalcon(boolean balcon) {
        this.balcon = balcon;
    }

    public boolean isVista() {
        return vista;
    }

    public void setVista(boolean vista) {
        this.vista = vista;
    }

    public boolean isAmenities() {
        return amenities;
    }

    public void setAmenities(boolean amenities) {
        this.amenities = amenities;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    public Hotel getHotel() { // Getter para hotel
        return hotel;
    }

    public void setHotel(Hotel hotel) { // Setter para hotel
        this.hotel = hotel;
    }

    @Override
    public String toString() { // Método toString() para una mejor representación
        return "Habitacion{" +
                "idHabitacion=" + idHabitacion +
                ", capacidadCamas=" + capacidadCamas +
                ", camaMatrimonial=" + camaMatrimonial +
                ", aireAcondicionado=" + aireAcondicionado +
                ", balcon=" + balcon +
                ", vista=" + vista +
                ", amenities=" + amenities +
                ", ocupada=" + ocupada +
                ", hotel=" + (hotel != null ? hotel.toString() : "No asignado") + // Representación del hotel
                '}';
    }
}
