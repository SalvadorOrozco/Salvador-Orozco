package Persistencia;
import java.time.LocalDate;
import Dominio.Hotel;
import Dominio.Huesped;
import Dominio.Habitacion;
import Dominio.Reserva;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PReserva {
    private static Conexion conexion = new Conexion();

    // Agregar una reserva
    public static boolean agregarReserva(Reserva reserva) {
        String sql = "INSERT INTO Reserva(idHuesped, idHotel, idHabitacion, cantidadPersonas, fechaInicio, fechaFin, pagada, fechaReserva, observacion) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                reserva.getHuesped().getIdHuesped(), reserva.getHotel().getIdHotel(),
                reserva.getHabitacion().getIdHabitacion(), reserva.getCantidadPersonas(),
                java.sql.Date.valueOf(reserva.getFechaInicio()), java.sql.Date.valueOf(reserva.getFechaFin()),
                reserva.isPagada(), java.sql.Date.valueOf(reserva.getFechaReserva()), reserva.getObservacion()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Eliminar una reserva por su ID
    public static boolean eliminarReserva(int idReserva) {
        String sql = "DELETE FROM Reserva WHERE idReserva=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idReserva));
        return conexion.consulta(sql, parametros);
    }

    // Modificar una reserva
    public static boolean modificarReserva(Reserva reserva) {
        String sql = "UPDATE Reserva SET idHuesped=?, idHotel=?, idHabitacion=?, cantidadPersonas=?, fechaInicio=?, fechaFin=?, pagada=?, fechaReserva=?, observacion=? " +
                "WHERE idReserva=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(
                reserva.getHuesped().getIdHuesped(), reserva.getHotel().getIdHotel(),
                reserva.getHabitacion().getIdHabitacion(), reserva.getCantidadPersonas(),
                java.sql.Date.valueOf(reserva.getFechaInicio()), java.sql.Date.valueOf(reserva.getFechaFin()),
                reserva.isPagada(), java.sql.Date.valueOf(reserva.getFechaReserva()), reserva.getObservacion(),
                reserva.getIdReserva()
        ));
        return conexion.consulta(sql, parametros);
    }

    // Conseguir una reserva específica por su ID
    public static Reserva conseguirReserva(int idReserva) {
        String sql = "SELECT * FROM Reserva WHERE idReserva=?";
        ArrayList<Object> parametros = new ArrayList<>(Arrays.asList(idReserva));
        List<List<Object>> resultado = conexion.seleccion(sql, parametros);

        if (resultado.isEmpty()) return null;

        List<Object> registro = resultado.get(0);

        int idHuesped = (int) registro.get(1);
        int idHotel = (int) registro.get(2);
        int idHabitacion = (int) registro.get(3);

        Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
        Hotel hotel = PHotel.conseguirHotel(idHotel);
        Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);

        return new Reserva(
                (int) registro.get(0),
                huesped,
                hotel,
                habitacion,
                (int) registro.get(4),
                ((java.sql.Date) registro.get(5)).toLocalDate(),
                ((java.sql.Date) registro.get(6)).toLocalDate(),
                (boolean) registro.get(7),
                ((java.sql.Date) registro.get(8)).toLocalDate(),
                (String) registro.get(9)
        );
    }

    // Listar todas las reservas
    public static ArrayList<Reserva> listarReservas() {
        String sql = "SELECT * FROM Reserva";
        List<List<Object>> registros = conexion.seleccion(sql, null);
        ArrayList<Reserva> reservas = new ArrayList<>();

        for (List<Object> registro : registros) {
            int idHuesped = (int) registro.get(1);
            int idHotel = (int) registro.get(2);
            int idHabitacion = (int) registro.get(3);

            Huesped huesped = PHuesped.conseguirHuesped(idHuesped);
            Hotel hotel = PHotel.conseguirHotel(idHotel);
            Habitacion habitacion = PHabitacion.conseguirHabitacion(idHabitacion);

            Reserva reserva = new Reserva(
                    (int) registro.get(0),
                    huesped,
                    hotel,
                    habitacion,
                    (int) registro.get(4),
                    ((java.sql.Date) registro.get(5)).toLocalDate(),
                    ((java.sql.Date) registro.get(6)).toLocalDate(),
                    (boolean) registro.get(7),
                    ((java.sql.Date) registro.get(8)).toLocalDate(),
                    (String) registro.get(9)
            );

            reservas.add(reserva);
        }
        return reservas;
    }
}
